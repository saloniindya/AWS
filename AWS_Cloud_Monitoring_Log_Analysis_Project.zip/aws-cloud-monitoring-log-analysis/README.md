# AWS Cloud Monitoring & Log Analysis System

A beginner-friendly internship mini-project that deploys an Apache web server on Amazon EC2, forwards Apache access/error logs to Amazon CloudWatch Logs, and provides queries plus optional alerting with CloudWatch metrics/alarms and Amazon SNS.

> **Important:** This repository contains the project files and setup instructions. It does not create AWS resources automatically. You must use your own AWS account, check costs, and follow your mentor's requirements.

## Architecture

Browser → EC2 (Amazon Linux 2023 + Apache) → CloudWatch Agent → CloudWatch Logs → Logs Insights → (optional) Metric Filter → CloudWatch Alarm → (optional) SNS email

## Project structure

- `scripts/install_apache.sh` — installs and starts Apache and publishes a test page.
- `scripts/install_cloudwatch_agent.sh` — installs the CloudWatch Agent package.
- `scripts/verify_project.sh` — checks Apache, the agent, and expected log files.
- `config/amazon-cloudwatch-agent.json` — collects Apache access and error logs.
- `config/logs-insights-queries.md` — example queries to investigate traffic and HTTP errors.
- `config/metric-filter-and-alarm.md` — console setup notes for optional alerting.
- `sample-logs/apache-access-sample.log` — example log events for learning/query planning.
- `sample-logs/apache-error-sample.log` — example error events.
- `docs/project-report-template.md` — report template for your internship submission.

## Prerequisites

- AWS account and permission to create/use EC2, IAM, CloudWatch Logs, CloudWatch alarms, and SNS if using the optional alerting extension.
- An EC2 instance running Amazon Linux 2023.
- An EC2 instance role with CloudWatch Agent permissions. For a lab, `CloudWatchAgentServerPolicy` is commonly used; review permissions and your organisation's rules first.
- A security group allowing inbound TCP 80 for the demo. If SSH is enabled, restrict TCP 22 to your own public IP; never open SSH to `0.0.0.0/0`.
- Outbound connectivity from the instance to AWS CloudWatch endpoints.

## Step-by-step implementation

### 1. Launch EC2

1. Open AWS Console → EC2 → Launch instance.
2. Name it `Cloud-Log-Lab`.
3. Select Amazon Linux 2023 and a small instance type available in your account.
4. Configure a key pair only if you need SSH.
5. Create a security group that permits HTTP/TCP 80 for the demo. Restrict SSH/TCP 22 to your current IP, or use AWS Systems Manager if configured.
6. Attach an IAM instance role that can publish CloudWatch Agent logs.
7. Launch and wait for status checks to pass.

### 2. Install Apache

Copy `scripts/install_apache.sh` to the instance, then run:

```bash
chmod +x install_apache.sh
sudo ./install_apache.sh
```

Open `http://EC2-PUBLIC-IP/` in a browser. Replace `EC2-PUBLIC-IP` with the instance's public IPv4 address.

### 3. Install the CloudWatch Agent

Copy `scripts/install_cloudwatch_agent.sh` to the instance and run:

```bash
chmod +x install_cloudwatch_agent.sh
sudo ./install_cloudwatch_agent.sh
```

### 4. Configure log collection

Copy `config/amazon-cloudwatch-agent.json` to:

`/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json`

Then run:

```bash
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl \
  -a fetch-config -m ec2 \
  -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json -s
```

Check agent status:

```bash
sudo systemctl status amazon-cloudwatch-agent
sudo tail -n 100 /opt/aws/amazon-cloudwatch-agent/logs/amazon-cloudwatch-agent.log
```

### 5. Verify logs

In the AWS Console, choose the same Region used for EC2 → CloudWatch → Logs → Log groups. Look for:

- `/internship/cloud-log-lab/apache-access`
- `/internship/cloud-log-lab/apache-error`

Refresh the website a few times and verify that new events appear in the access log stream.

### 6. Analyze logs

Open CloudWatch → Logs Insights, select the access log group, and use the queries in `config/logs-insights-queries.md`. Start with a broad recent-events query, then adapt filters to the actual log format.

### 7. Optional alerting extension

Follow `config/metric-filter-and-alarm.md` to create a metric filter, CloudWatch alarm, and SNS email subscription. Test the metric filter against real log events before relying on it. Confirm the SNS email subscription.

### 8. Test and document

Use `scripts/verify_project.sh` on the EC2 instance. Save screenshots of the web page, log groups, Logs Insights query results, and optional alarm history. Fill in `docs/project-report-template.md`.

### 9. Clean up

Terminate the EC2 instance when finished. Remove unused log groups, alarms, metric filters, SNS topics, and the lab IAM role only when no longer needed. Check billing for remaining resources. Charges may apply for EC2, log ingestion/storage, alarms, SNS, data transfer, or other services.

## Troubleshooting

- **Web page not loading:** confirm EC2 is running, HTTP/TCP 80 is allowed in the security group, Apache is active, and you are using the correct public IP.
- **No logs:** confirm IAM role attachment, agent status, JSON validity, log file paths, correct Region, and outbound access.
- **Agent errors:** inspect `/opt/aws/amazon-cloudwatch-agent/logs/amazon-cloudwatch-agent.log`.
- **No query results:** choose the correct log group/time range and inspect raw events before changing the query.
- **Alarm not firing:** confirm the metric filter matches real events and wait for metric publication and alarm evaluation.

## Security notes

- Never store AWS access keys in this repository or on the instance.
- Do not share private SSH keys or screenshots showing secrets.
- Use least-privilege permissions.
- Restrict administrative access.
- This is a learning lab, not a production-ready monitoring system.
