#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root: sudo $0" >&2
  exit 1
fi

dnf install -y httpd
systemctl enable --now httpd

cat > /var/www/html/index.html <<'HTML'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AWS Cloud Monitoring Lab</title>
</head>
<body>
  <h1>AWS Cloud Monitoring Lab</h1>
  <p>Apache is running on this EC2 instance.</p>
  <p>Project: Cloud Monitoring and Log Analysis System</p>
</body>
</html>
HTML

systemctl is-active --quiet httpd
echo "Apache installed and running."
echo "Test in a browser: http://<EC2-PUBLIC-IP>/"
