#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root: sudo $0" >&2
  exit 1
fi

dnf install -y amazon-cloudwatch-agent
echo "CloudWatch Agent package installed."
echo "Next: copy config/amazon-cloudwatch-agent.json to:"
echo "  /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json"
echo "Then start it using the command in README.md."
