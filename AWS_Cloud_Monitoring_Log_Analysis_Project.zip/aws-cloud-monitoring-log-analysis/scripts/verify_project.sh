#!/usr/bin/env bash
set -u

echo "=== Apache service ==="
if systemctl is-active --quiet httpd; then
  echo "PASS: httpd is active"
else
  echo "FAIL: httpd is not active"
fi

echo
echo "=== CloudWatch Agent service ==="
if systemctl is-active --quiet amazon-cloudwatch-agent; then
  echo "PASS: amazon-cloudwatch-agent is active"
else
  echo "CHECK: amazon-cloudwatch-agent is not active"
fi

echo
echo "=== Apache log files ==="
for f in /var/log/httpd/access_log /var/log/httpd/error_log; do
  if [[ -f "$f" ]]; then
    echo "FOUND: $f"
    ls -lh "$f"
  else
    echo "MISSING: $f"
  fi
done

echo
echo "=== Recent access log entries ==="
if [[ -f /var/log/httpd/access_log ]]; then
  tail -n 5 /var/log/httpd/access_log
fi

echo
echo "If logs are not visible in CloudWatch, inspect the agent log:"
echo "sudo tail -n 100 /opt/aws/amazon-cloudwatch-agent/logs/amazon-cloudwatch-agent.log"
