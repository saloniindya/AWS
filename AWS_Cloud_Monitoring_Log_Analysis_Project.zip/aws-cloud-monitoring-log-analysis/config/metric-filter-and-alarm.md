# Optional extension: metric filter, alarm, and SNS

This part is configured in the AWS Console because metric filter syntax depends on the actual Apache access-log format.

## A. Generate a controlled 404 event

Open a URL that does not exist, for example:

`http://EC2-PUBLIC-IP/this-page-should-not-exist`

Verify that the Apache access log contains a `404` response.

## B. Create a metric filter

1. CloudWatch → Logs → Log groups → `/internship/cloud-log-lab/apache-access`.
2. Choose **Create metric filter**.
3. Test candidate patterns against actual log events in the console. Do not assume a pattern is correct until it matches your real log format.
4. Use a namespace such as `Internship/CloudLogLab`, metric name `HttpErrorCount`, and metric value `1`.
5. Create the filter and generate another controlled 404 event.
6. Confirm the metric begins receiving data. Publication is not necessarily immediate.

## C. Create an alarm

1. CloudWatch → Alarms → Create alarm.
2. Select the `Internship/CloudLogLab` metric.
3. For a lab test, set a low threshold, such as at least one matching event in the chosen evaluation period.
4. Name it `HttpErrorAlarm`.
5. Configure the alarm action to notify an SNS topic if you complete section D.

## D. Configure SNS email

1. SNS → Topics → Create topic → Standard.
2. Name it `CloudLogLabAlerts`.
3. Create an email subscription and confirm it from the inbox.
4. Attach this topic as the alarm's notification action.
5. Trigger a controlled matching event and inspect alarm history and email.

## Important

- Metric filters only work when their pattern matches the actual log format.
- Allow time for log ingestion, metric publication, and alarm evaluation.
- Keep alert thresholds appropriate for a demo; this is not production alerting.
- Delete unused alarm/topic resources after testing to avoid ongoing charges.
