# CloudWatch Logs Insights queries

Select `/internship/cloud-log-lab/apache-access` and a time range that includes recent requests.

## 1. Show the newest events

```sql
fields @timestamp, @message
| sort @timestamp desc
| limit 30
```

## 2. Search for common HTTP 4xx and 5xx responses

Apache access logs often contain the status code after the request. This example is a starting point; confirm it matches your actual log format.

```sql
fields @timestamp, @message
| filter @message like / 4[0-9][0-9] / or @message like / 5[0-9][0-9] /
| sort @timestamp desc
| limit 50
```

## 3. Count events over time

```sql
fields @timestamp
| stats count(*) as request_count by bin(5m)
| sort @timestamp asc
```

## Notes

- Log formats differ; inspect raw events before relying on a regular expression.
- A query with no results does not necessarily mean the server has no errors. Check the selected log group and time range.
- Query charges may apply. Avoid querying unnecessarily large time windows.
