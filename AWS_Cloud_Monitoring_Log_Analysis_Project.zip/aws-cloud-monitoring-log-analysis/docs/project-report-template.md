# AWS Cloud Monitoring & Log Analysis System — Project Report

## 1. Objective
Explain the goal of collecting Apache logs centrally and investigating HTTP errors.

## 2. Architecture
Describe: Browser → EC2/Apache → CloudWatch Agent → CloudWatch Logs → Logs Insights → optional metric filter/alarm → optional SNS email.

## 3. AWS services used
- EC2:
- IAM:
- CloudWatch Agent:
- CloudWatch Logs / Logs Insights:
- CloudWatch alarm (optional):
- SNS (optional):

## 4. Implementation steps
Record the actions performed and any changes from the guide.

## 5. Test results
| Test | Expected result | Actual result | Pass/Fail |
|---|---|---|---|
| Open the web page | Page loads | | |
| Generate requests | Access log entries appear | | |
| Search logs | Query returns events | | |
| Generate 404 | Access log contains 404 | | |
| Alarm extension | Alarm evaluates as expected | | |
| SNS extension | Confirmed email receives notification | | |

## 6. Screenshots
Insert screenshots of the web page, EC2 status, CloudWatch log groups, Logs Insights query results, and optional alarm history. Hide account IDs, public IPs if not needed, emails, and any secrets.

## 7. Troubleshooting
Describe each issue, its root cause, and the fix.

## 8. Security and cost controls
Explain IAM role usage, SSH restrictions, secret handling, and cleanup.

## 9. What I learned
Summarize what you learned about EC2, IAM, centralized logging, monitoring, and troubleshooting.

## 10. Future improvements
Examples: structured JSON application logs, dashboards, automated deployment, log retention policy, and more precise error metrics.
